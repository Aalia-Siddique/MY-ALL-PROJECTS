To run provided code:
1- Download and Install the Jupyter Notebook in your system and all the Python Libaraies and Pakages Required.
2- Sequentially run all the cells
